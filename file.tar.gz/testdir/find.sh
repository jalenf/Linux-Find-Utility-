#!/bin/bash
gcc find.c -o find && ./find find dir1 > part1out.txt #good

gcc find.c -o find && ./find find dir1 -name test3 > part2-1out.txt 

gcc find.c -o find && ./find find dir3 -mmin +10 > part2-2out.txt 

gcc find.c -o find && ./find find dir1 -inum 59507571 > part2-3out.txt 

gcc find.c -o find && ./find find dir1 -name test4 -delete > part3-1out.txt 

gcc find.c -o find && ./find find dir1/dir2 -mmin +10 -delete > part3-2out.txt 
